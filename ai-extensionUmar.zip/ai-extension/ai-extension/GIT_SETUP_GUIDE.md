# Quick Git Installation Guide for VS Code

## Step 1: Download Git
1. Go to: https://git-scm.com/download/win
2. Download "64-bit Git for Windows Setup"
3. Run the installer

## Step 2: Installation Settings (Important!)
- When asked about "Adjusting your PATH environment":
  - Choose "Use Git from the Windows Command Prompt" (middle option)
- When asked about line endings:
  - Choose "Checkout Windows-style, commit Unix-style line endings" (default)
- Accept all other defaults

## Step 3: After Installation
1. Restart VS Code completely (close and reopen)
2. Open your project folder again
3. Press Ctrl + Shift + G to open Source Control
4. You should now see "Initialize Repository" button

## Step 4: Publish to GitHub
1. Click "Initialize Repository"
2. All your files will appear in the changes list
3. Enter commit message in the text box at the top:
   "feat: Add Test Data Generator and Playwright TypeScript support"
4. Click the checkmark (✓) to commit
5. Click "Publish to GitHub" button
6. Choose repository name: ai-code-generator-extension
7. Select Public/Private and click "Publish to GitHub"

## Troubleshooting
If you still don't see Git options:
- Check Windows PATH contains Git
- Restart computer if needed
- Use Command Palette (Ctrl+Shift+P) and type "Git: Initialize Repository"