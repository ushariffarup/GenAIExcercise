# AI Code Generator Chrome Extension

An intelligent Chrome extension that generates test automation code using AI. Supports multiple frameworks including Selenium, Playwright, and comprehensive test data generation.

## Features

### 🚀 **Code Generation Modes**
- **Feature Files**: Generate Cucumber/Gherkin feature files with realistic scenarios
- **Page Objects**: Create Page Object Model classes for:
  - Java + Selenium WebDriver
  - TypeScript + Playwright
- **Test Data Generator**: Generate comprehensive JSON test data with South Indian realistic datasets

### 🎯 **Supported Combinations**
- **Java + Selenium**: Full support for page objects and step definitions
- **TypeScript + Playwright**: Modern async/await page object patterns
- **Language-Independent**: Feature files and test data work with any combination

### 🔧 **AI Providers**
- Groq API
- OpenAI API
- TestLeaf API
- Claude (coming soon)

## Installation

1. Clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode"
4. Click "Load unpacked" and select the extension directory
5. Configure your AI API keys in the Settings tab

## Usage

1. **Inspect Elements**: Click the "Inspect" button and select DOM elements on any webpage
2. **Choose Generation Mode**: Select one or more options:
   - ✅ Feature File
   - ✅ Page Class  
   - ✅ Test Data
3. **Select Language/Engine**: Choose your preferred combination
4. **Generate**: Click "Generate" to create your automation code

## Recent Updates

### ✨ **Test Data Generator** (Latest)
- Generates realistic South Indian test data in JSON format
- Multiple user personas (admin, regular user, guest)
- Comprehensive scenarios (positive, negative, boundary cases)
- Easy integration with existing test frameworks

### 🎭 **Playwright + TypeScript Support**
- Modern async/await patterns
- Proper TypeScript typing with Page and Locator
- Enterprise-ready code structure

## Project Structure

```
ai-extension/
├── manifest.json          # Extension manifest
├── panel.html            # Main UI
├── bg.js                 # Background service worker
├── src/
│   ├── scripts/
│   │   ├── prompts.js    # AI prompt templates
│   │   ├── chat.js       # Main UI logic
│   │   └── api/          # API integrations
│   ├── content/          # Content scripts
│   └── styles/           # CSS files
└── lib/                  # External libraries
```

## Development

The extension uses:
- **Manifest V3** for modern Chrome extension standards
- **ES6 Modules** for clean code organization
- **Marked.js** for markdown rendering
- **Prism.js** for syntax highlighting

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- TestLeaf for inspiration and API support
- Chrome Extensions community for best practices
- Open source contributors for various libraries used